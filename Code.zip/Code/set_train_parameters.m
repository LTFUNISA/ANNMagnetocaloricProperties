function [cycles_number,success,learningrate,momentum]=set_train_parameters()
cycles_number =10000; 
success=0.00005; 
learningrate=0.3;  
momentum=0;  
end